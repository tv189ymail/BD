﻿// 一级筛选页面异常
muban.首图2.二级.desc = '.data.visible-xs:eq(0)&&Text;;;p.data:eq(-2)&&Text;p.data:eq(-3)&&Text';
muban.首图2.二级.content = '.detail-content&&Text';
var rule={
    title:'我爱电影网',
    模板:'首图2',
    host:'https://www.5imv.cc',
    url:'/vodtype/fyclass-fypage/',
    searchUrl:'/vodsearch/page/fypage/wd/**/',
    class_name:'电影&电视剧&综艺&动漫&哔哩',
    class_url:'1&2&3&4&5',
    搜索:muban.首图2.搜索1,
}