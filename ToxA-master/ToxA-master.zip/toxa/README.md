﻿### 1. TVBox 开源版  
https://agit.ai/explore/repos      
https://agit.ai/xnywzq1816

https://agit.ai/l      
https://agit.ai/zhanghong

https://agit.ai/guot54/ygbh
  

https://agit.ai/Yoursmile7      
https://agit.ai/ccvv

https://agit.ai/zqk219      
https://agit.ai/wangjie

https://agit.ai/xiaohewanwan      
https://agit.ai/138001380000

https://agit.ai/mys2099      
https://agit.ai/zhanghong
 
- 本地功能，这个版本也具备了，只需要开启存储权限，在配置地址栏输入本地规则地址即可。  
- clan://localhost/存放路径/本地配置文件夹名/接口文件名.json（或 .txt 格式文件）；  

### 2. 长按-点最下-拷贝-粘贴-完成
      把复制出来的链接里的src要改成raw
[欢迎大家一起交流分享---TVBox
https://gitea.com/explore/repos